- Java Version 23

- `envelop.json` contains the batch to send.

- Program outputs `response.json` with the response.

- Usage:
  - Compile: `javac Client.java` if `Client.class` does not exist.
  - Run: `java Client -u <username> -p <password>`
